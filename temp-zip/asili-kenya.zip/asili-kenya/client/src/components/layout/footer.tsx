import { Link } from "wouter";
import { CATEGORIES, SOCIAL_LINKS, CONTACT_INFO, COLORS } from "@/lib/constants";

export default function Footer() {
  return (
    <footer style={{ backgroundColor: COLORS.secondary }} className="text-white mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div>
            <h2 className="font-display font-bold text-2xl mb-4">ASILI KENYA</h2>
            <p className="text-white/80 mb-6">Connecting you to authentic Kenyan craftsmanship and culture.</p>
            <div className="flex space-x-4">
              <a 
                href={SOCIAL_LINKS.facebook} 
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition" 
                aria-label="Facebook"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a 
                href={SOCIAL_LINKS.instagram} 
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition" 
                aria-label="Instagram"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a 
                href={SOCIAL_LINKS.twitter} 
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition" 
                aria-label="Twitter"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-twitter"></i>
              </a>
              <a 
                href={SOCIAL_LINKS.whatsapp} 
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition" 
                aria-label="WhatsApp"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-whatsapp"></i>
              </a>
            </div>
          </div>
          
          {/* Categories */}
          <div>
            <h3 className="font-medium text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              {CATEGORIES.slice(0, 6).map((category) => (
                <li key={category.slug}>
                  <Link 
                    href={`/category/${category.slug}`} 
                    className="text-white/80 hover:text-white transition"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Information */}
          <div>
            <h3 className="font-medium text-lg mb-4">Information</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-white/80 hover:text-white transition">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-white/80 hover:text-white transition">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-white/80 hover:text-white transition">
                  Shipping Information
                </Link>
              </li>
              <li>
                <Link href="/returns" className="text-white/80 hover:text-white transition">
                  Return Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-white/80 hover:text-white transition">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-white/80 hover:text-white transition">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="font-medium text-lg mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-3" style={{ color: COLORS.accent }}></i>
                <span>{CONTACT_INFO.email}</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone-alt mt-1 mr-3" style={{ color: COLORS.accent }}></i>
                <span>{CONTACT_INFO.phone}</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3" style={{ color: COLORS.accent }}></i>
                <span>{CONTACT_INFO.address}</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Sell With Us CTA */}
        <div className="border-t border-white/20 mt-8 pt-8 flex flex-col items-center">
          <div className="max-w-2xl text-center mb-6">
            <h3 className="text-xl font-semibold mb-2">Want to sell with us?</h3>
            <p className="text-white/80 mb-4">
              Join our marketplace of Kenyan artisans and entrepreneurs. Connect with customers who value authentic Kenyan products.
            </p>
            <Link href="/contact?seller=true">
              <button 
                className="px-6 py-3 rounded-md font-medium text-white transition-all"
                style={{ backgroundColor: COLORS.primary }}
              >
                Sell With Us
              </button>
            </Link>
          </div>
          <p className="text-white/60 text-sm">
            &copy; {new Date().getFullYear()} Asili Kenya. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
